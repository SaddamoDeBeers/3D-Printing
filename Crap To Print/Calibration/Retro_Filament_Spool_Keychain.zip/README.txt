                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2324616
Retro Filament Spool Keychain by TheNewHobbyist is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

I found [Heliox's](https://www.thingiverse.com/Heliox/about) "[Beautiful Mini Filament KeyChain](https://www.thingiverse.com/thing:2300389)" on the Adafruit news feed and thought they were completely amazing. While I have a couple of spools that look like Heliox's modern spool design, the majority of my filament stock is on the older, chunky black spools of yesteryear.

I decided to create my own version of the keychains with the retro (can we call it that yet?) spool design from when I started 3D printing in 2011.

I'm still learning best practices for Fusion 360, so the design could be a bit more parametric, that being said I've included the .f3d and .step files if you'd like to make changes.

![Retro Filament Spool Animated Build](http://i.imgur.com/K5lj7Hm.gif)



# Print Settings

Printer Brand: MakerBot
Printer: MakerBot Replicator 2
Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 50%

Notes: 
I printed these at 50% infill which is more than is totally necessary, but I wanted them to be durable. 

They're designed to push fit together (with some effort) and have a 0.2mm tolerance built in. This seems to work well on my stock Replicator 2. If this is too small for your printer you may need to edit the model to include a slightly larger press-fit tolerance. If it's too loose a dab of glue should be all you need.